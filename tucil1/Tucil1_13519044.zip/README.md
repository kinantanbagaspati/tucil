# Tucil1_13519044

Program Penyelesaian Cryptarithmetic dengan Algoritma Brute Force

Requirement Program
- Compiler g++ yang lebih baru daripada 6.0

Cara Menggunakan Program
- Program dapat dicompile dalam bin menggunakan command: g++ ../src/cryptarithms.cpp -o cryptarithms
- Program cryptarithms cryptarithms.exe membaca file input.txt pada folder test, oleh karena itu silahkan copy test yang ingin diuji dalam input.txt

Author
Kinantan Arya Bagaspati (13519044)